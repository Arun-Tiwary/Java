package bs;

public class main {

	public static void main(String[] args) { // entry point of the program.
		// TODO Auto-generated method stub

		emploe e = new emploe();
		e.name = "Akash";
		e.city = "Jaipur";
		e.age = 22;
		System.out.println("The " + "name " + "is " + e.name);
		System.out.println("The " + "city " + "is " + e.city);
		System.out.println("The " + "age " + "is " + e.age);
	}

}
