package bs;

public class emploe {
	
	public String name;
	public String city;
	public int age;
	

}
